import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert } from 'react-native';

const SignupScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');

 const validateAndNavigate = () => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^\+92-3\d{2}-\d{7}$/;
  const usernameRegex = /^[A-Za-z]+$/;

  if (!emailRegex.test(email)) {
    Alert.alert('Invalid Email', 'Please enter a valid email address.');
    return;
  }
  if (password.length < 8) {
    Alert.alert('Weak Password', 'Password must be at least 8 characters long.');
    return;
  }
  if (!usernameRegex.test(username)) {
    Alert.alert('Invalid Username', 'Username should contain only alphabets.');
    return;
  }
  if (!phoneRegex.test(phone)) {
    Alert.alert('Invalid Phone Number', 'Phone number must match +92-3xx-xxxxxxx format.');
    return;
  }

  // If all validations pass, navigate to Login
  navigation.navigate('Login');
};


  return (
    <View style={styles.container}>
      <Text style={styles.title}>Signup</Text>
      <TextInput placeholder="Email" style={styles.input} value={email} onChangeText={setEmail} />
      <TextInput placeholder="Password" style={styles.input} value={password} secureTextEntry onChangeText={setPassword} />
      <TextInput placeholder="Username" style={styles.input} value={username} onChangeText={setUsername} />
      <TextInput placeholder="Phone (+92-3xx-xxxxxxx)" style={styles.input} value={phone} onChangeText={setPhone} />
      <TouchableOpacity onPress={validateAndNavigate} style={styles.button}>
        <Text style={styles.buttonText}>Signup</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 15,
    backgroundColor: '#fff',
  },
  button: {
    height: 50,
    backgroundColor: '#007bff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
});

export default SignupScreen;
