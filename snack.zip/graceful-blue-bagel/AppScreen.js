import React from 'react';
import { View, Text, Image, FlatList, StyleSheet, TouchableOpacity } from 'react-native';

const orders = [
  { id: '1', title: 'Mosambi Juice', date: '02, Wed 12:48', price: 'Rs. 200', image: 'https://juiceland.pk/wp-content/uploads/2021/04/Mausami_Juice-768x768.jpg' },
  { id: '2', title: 'Caramel Cold Coffee', date: '27, Fri 7:40', price: 'Rs. 450', image: 'https://i0.wp.com/chasety.com/wp-content/uploads/2024/03/realchasecurtis_Caramel_Hazelnut_Iced_Coffee_sitting_in_a_mason_930faa1b-ba13-47d5-b9dd-f4da71bb57a1.png?resize=768%2C1200&ssl=1' },
  { id: '3', title: 'Behari Kebab Pizza', date: '21, Mon 9:30', price: 'Rs.900', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4ckXIbErYg7xTFLcp6JcqnMnSjLD8bDnNaw&s' },
];

const App = () => {
  const renderItem = ({ item }) => (
    <View style={styles.orderItem}>
      <Image source={{ uri: item.image }} style={styles.orderImage} />
      <View style={styles.orderTextContainer}>
        <Text style={styles.orderTitle}>{item.title}</Text>
        <Text style={styles.orderDate}>{item.date}</Text>
      </View>
      <Text style={styles.orderPrice}>{item.price}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.profileHeader}>
        <Text style={styles.profileTitle}>My Profile</Text>
        <TouchableOpacity>
          <Text style={styles.profileIcon}>↻</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.profileCard}>
        <Image
          source={{ uri:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR37866QE51X9dG_Gh_N1GKaM0m5nVNdUACcg&s' }}
          style={styles.profileImage}
        />
        <Text style={styles.profileName}>Muhammad Uzair</Text>
        <View style={styles.profileStats}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>9,500</Text>
            <Text style={styles.statLabel}>Product Sells</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>69M+</Text>
            <Text style={styles.statLabel}>Earnings</Text>
          </View>
        </View>
      </View>

      <View style={styles.ordersHeader}>
        <Text style={styles.ordersTitle}>Recent Orders</Text>
        <TouchableOpacity>
          <Text style={styles.seeAll}>See All</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={orders}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    padding: 20,
  },
  profileHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  profileTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fafbfc'
  },
  profileIcon: {
    fontSize: 18,
    color: '#fafbfc'
  },
  profileCard: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 20,
    marginTop: 20,
    alignItems: 'center',
  },
  profileImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  profileName: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: 'bold',
  },
  profileStats: {
    flexDirection: 'row',
    marginTop: 20,
  },
  statItem: {
    marginHorizontal: 20,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  statLabel: {
    fontSize: 12,
    color: '#888',
  },
  ordersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 30,
  },
  ordersTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fafbfc'
  },
  seeAll: {
    color: '#fafbfc',
  },
  orderItem: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    padding: 15,
    marginTop: 15,
    borderRadius: 20,
    alignItems: 'center',
  },
  orderImage: {
    width: 50,
    height: 50,
    borderRadius: 10,
  },
  orderTextContainer: {
    flex: 1,
    marginLeft: 10,
  },
  orderTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  orderDate: {
    fontSize: 12,
    color: '#888',
  },
  orderPrice: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default App;